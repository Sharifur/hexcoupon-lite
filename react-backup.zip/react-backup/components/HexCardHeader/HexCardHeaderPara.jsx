import React from 'react';

const HexCardHeaderPara = ({HeaderPara}) => {
    return (
        <>            
            <p className="hexDashboard__card__header__para mt-2">{HeaderPara}</p>
        </>
    );
};

export default HexCardHeaderPara;