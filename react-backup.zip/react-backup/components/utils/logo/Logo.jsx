import logoImage from '../../../assets/img/logo.png';

const Logo = () => {
    return (
        <img src={logoImage} alt="logo" />
    );
};

export default Logo;