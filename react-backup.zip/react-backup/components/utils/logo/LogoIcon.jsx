import logoIcon from '../../assets/img/logoIcon.png';

const LogoIcon = () => {
    return (
        <img src={logoIcon} alt="logo" />
    );
};

export default LogoIcon;