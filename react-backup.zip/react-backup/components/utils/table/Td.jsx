/* eslint-disable react/prop-types */

const Td = ({ children }) => {
    return (
        <>
            <td>{children}</td>
        </>
    );
};

export default Td;