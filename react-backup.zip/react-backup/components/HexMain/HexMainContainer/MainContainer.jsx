import React from "react";

const MainContainer = ({children}) => {

	return (
		<div className="MainContainer">
            {children}
		</div>
	);
}

export default MainContainer;
